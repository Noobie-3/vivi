<?php
$foo = "Hellwddo";
echo ($foo)
  ?>